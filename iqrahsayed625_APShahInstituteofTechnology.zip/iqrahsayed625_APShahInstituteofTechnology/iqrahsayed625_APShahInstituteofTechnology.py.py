# =============================================================================
# Section 0: Import Libraries
# =============================================================================
import pandas as pd
import numpy as np
import warnings
import re
import xgboost as xgb
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_absolute_percentage_error

warnings.filterwarnings('ignore')


# =============================================================================
# Section 1: Core Data Preprocessing Function
# =============================================================================
def preprocess_data(df, artifacts, is_train=True):
    """
    Cleans, imputes, engineers features, and encodes categorical variables.
    Uses an 'artifacts' dictionary to apply transformations learned from the train set
    consistently to the test set.
    """
    df = df.copy()

    # --- Initial Cleanup ---
    columns_to_drop = ['CITY', 'Zipcode', 'VILLAGE', 'Location', 'K022-Nearest Mandi Name']
    if is_train:
        columns_to_drop.append('FarmerID')
    df.drop(columns=columns_to_drop, inplace=True, errors='ignore')
    df.columns = df.columns.str.strip()

    # --- Feature Engineering & Imputation ---
    def get_avg_temp(temp_str):
        if isinstance(temp_str, str) and '/' in temp_str:
            try: return np.mean([float(x.strip()) for x in temp_str.split('/')])
            except: return np.nan
        return np.nan
    for col in [c for c in df.columns if 'Ambient temperature' in c]: df[col + '_avg'] = df[col].apply(get_avg_temp)
    
    # For these specific columns, a missing value logically implies zero
    cols_to_fill_zero = ['Avg_Disbursement_Amount_Bureau', 'No_of_Active_Loan_In_Bureau','Non_Agriculture_Income', 'Total_Land_For_Agriculture']
    for col in cols_to_fill_zero:
        if col in df.columns: df[col].fillna(0, inplace=True)
    
    # Use median imputation for other numeric NaNs
    if is_train:
        artifacts['medians'] = df.select_dtypes(include=np.number).median()
    df.fillna(artifacts.get('medians', pd.Series()), inplace=True)
    
    # Use 'Unknown' for categorical NaNs
    for col in df.select_dtypes(include='object').columns: df[col].fillna('Unknown', inplace=True)

    # Create new, potentially more predictive features
    df['Total_Rainfall'] = df['K022-Seasonal Average Rainfall (mm)'] + df['R022-Seasonal Average Rainfall (mm)']
    df['Land_Per_Person'] = df['Total_Land_For_Agriculture'] / (df['Land Holding Index source (Total Agri Area/ no of people)'] + 1)
    df['Loan_Burden_Index'] = df['Avg_Disbursement_Amount_Bureau'] * df['No_of_Active_Loan_In_Bureau']
    house_cols = ['perc_Households_with_Pucca_House_That_Has_More_Than_3_Rooms', 'mat_roof_Metal_GI_Asbestos_sheets', 'perc_of_Wall_material_with_Burnt_brick']
    df['House_Infra_Score'] = df[house_cols].mean(axis=1)
    df['perc_pop_deprived_of_electricity'] = 100 - df['perc_of_pop_living_in_hh_electricity']
    deprivation_cols = ['perc_Households_do_not_have_KCC_With_The_Credit_Limit_Of_50k', 'Women_15_19_Mothers_or_Pregnant_at_time_of_survey', 'perc_pop_deprived_of_electricity']
    df['Deprivation_Index'] = df[deprivation_cols].mean(axis=1)
    
    # Drop original columns used for feature engineering
    original_cols_to_drop = [c for c in df.columns if 'Ambient temperature' in c and '_avg' not in c] + house_cols + deprivation_cols + ['K022-Seasonal Average Rainfall (mm)', 'R022-Seasonal Average Rainfall (mm)','Land Holding Index source (Total Agri Area/ no of people)', 'Avg_Disbursement_Amount_Bureau','No_of_Active_Loan_In_Bureau', 'perc_of_pop_living_in_hh_electricity']
    df.drop(columns=original_cols_to_drop, inplace=True, errors='ignore')

    # --- Categorical Variable Encoding ---
    ordinal_map = {'Poor': 0, 'Average': 1, 'Good': 2}
    for col in df.select_dtypes(include=['object']).columns:
        if all(item in list(ordinal_map.keys()) + ['Unknown'] for item in df[col].unique()):
            df[col] = df[col].map(ordinal_map).fillna(-1)
        else:
            if is_train:
                le = LabelEncoder(); df[col] = le.fit_transform(df[col].astype(str)); artifacts[col] = le
            else:
                le = artifacts.get(col)
                if le:
                    # Handle new, unseen categories in the test data by mapping them to 'Unknown'
                    known_labels = list(le.classes_); df[col] = df[col].astype(str).apply(lambda x: x if x in known_labels else 'Unknown')
                    if 'Unknown' not in le.classes_: le.classes_ = np.append(le.classes_, 'Unknown')
                    df[col] = le.transform(df[col])
                else: df[col] = -1
    
    # Sanitize column names to remove special characters for model compatibility
    sanitized_columns = [re.sub(r'[^A-Za-z0-9_]+', '_', col) for col in df.columns]
    df.columns = sanitized_columns
    
    return df, artifacts

# =============================================================================
# Section 2: Main Training, Evaluation, and Prediction Workflow
# =============================================================================
print("--- Starting Full Training, Evaluation & Prediction Pipeline ---")

# --- Step 1: Load Datasets ---
try:
    file_path = 'LTF Challenge data with dictionary.xlsx'
    full_train_df = pd.read_excel(file_path, sheet_name='TrainData')
    full_test_df = pd.read_excel(file_path, sheet_name='TestData')
    print("1. Train and Test data loaded successfully.")
except FileNotFoundError:
    print(f"ERROR: Data file not found at '{file_path}'. Please update the path.")
    exit()

test_farmer_ids = full_test_df['FarmerID']

# --- Step 2: Preprocess Train Data ---
artifacts = {}
print("\n2. Preprocessing training data...")
train_processed, artifacts = preprocess_data(full_train_df, artifacts, is_train=True)

# Define the target and feature columns
target_col = 'Target_Variable_Total_Income'
features = [col for col in train_processed.columns if col != target_col]
X_full = train_processed[features]
# Log-transform the target to handle skewed distribution
y_full_log = np.log1p(train_processed[target_col])

# --- Step 3: Create a Validation Split for Performance Evaluation ---
X_train, X_val, y_train_log, y_val_log = train_test_split(X_full, y_full_log, test_size=0.2, random_state=42)

# --- Step 4: Train and Evaluate Models on the Split Data ---
print("\n3. Training models on 80% of data for evaluation...")
model_xgb_eval = xgb.XGBRegressor(n_estimators=1000, learning_rate=0.05, max_depth=9, subsample=0.8, colsample_bytree=0.9, random_state=42, n_jobs=-1, objective='reg:squarederror', early_stopping_rounds=50)
# Convert to NumPy arrays (.values) to prevent a potential XGBoost/pandas compatibility bug
model_xgb_eval.fit(X_train.values, y_train_log.values, eval_set=[(X_val.values, y_val_log.values)], verbose=False)

model_lgb_eval = lgb.LGBMRegressor(n_estimators=1000, learning_rate=0.08, max_depth=7, subsample=0.8, colsample_bytree=0.8, random_state=42, n_jobs=-1, objective='regression_l1',verbose=-1)
model_lgb_eval.fit(X_train, y_train_log, eval_set=[(X_val, y_val_log)], eval_metric='mape', callbacks=[lgb.early_stopping(50, verbose=False)])

# --- Step 4.5: Calculate and display MAPE on the validation set ---
print("\n4. Calculating MAPE on the validation set...")
y_val = np.expm1(y_val_log)
preds_xgb = np.expm1(model_xgb_eval.predict(X_val.values))
preds_lgb = np.expm1(model_lgb_eval.predict(X_val))
ensembled_preds = (preds_xgb + preds_lgb) / 2
print("======================================")
print("        MODEL PERFORMANCE (MAPE)")
print("======================================")
print(f"XGBoost Model:           {mean_absolute_percentage_error(y_val, preds_xgb):.4f}")
print(f"LightGBM Model:          {mean_absolute_percentage_error(y_val, preds_lgb):.4f}")
print("--------------------------------------")
print(f"Ensembled Model (on Val): {mean_absolute_percentage_error(y_val, ensembled_preds):.4f}")
print("======================================")

# --- Step 5: Re-train Final Models on the FULL Training Data ---
# This step uses all available data to make the final models as accurate as possible.
print("\n5. Re-training final models on 100% of the training data...")
final_model_xgb = xgb.XGBRegressor(n_estimators=model_xgb_eval.best_iteration, learning_rate=0.05, max_depth=9, subsample=0.8, colsample_bytree=0.9, random_state=42, n_jobs=-1, objective='reg:squarederror')
final_model_xgb.fit(X_full.values, y_full_log.values, verbose=False)

final_model_lgb = lgb.LGBMRegressor(n_estimators=model_lgb_eval.best_iteration_, learning_rate=0.08, max_depth=7, subsample=0.8, colsample_bytree=0.8, random_state=42, n_jobs=-1, objective='regression_l1',verbose=-1)
final_model_lgb.fit(X_full, y_full_log)

# --- Step 6: Preprocess Test Data and Make Final Predictions ---
print("\n6. Preprocessing test data and making final predictions...")
test_processed, _ = preprocess_data(full_test_df, artifacts, is_train=False)
test_processed = test_processed.reindex(columns=features, fill_value=0)

pred_xgb_log = final_model_xgb.predict(test_processed.values)
pred_lgb_log = final_model_lgb.predict(test_processed)
ensembled_log_pred = (pred_xgb_log + pred_lgb_log) / 2.0
final_predictions = np.expm1(ensembled_log_pred)

# --- Step 7: Generate the Submission File ---
print("\n7. Creating the submission file...")
submission_df = pd.DataFrame({
    'FarmerID': test_farmer_ids,
    'Target_Variable/Total Income': final_predictions
})

# Ensure income predictions are not negative
submission_df['Target_Variable/Total Income'] = submission_df['Target_Variable/Total Income'].clip(lower=0)

submission_df['FarmerID'] = submission_df['FarmerID'].astype('int64')
submission_df['Target_Variable/Total Income'] = submission_df['Target_Variable/Total Income'].round(0).astype('int64')

# Define the filename and save the dataframe to an Excel file
submission_filename_csv = 'iqrahsayed625_APShahInstituteofTechnology.csv'
submission_df.to_csv(submission_filename_csv, index=False)

print("\n==================================================")
print(f"SUCCESS! Submission file '{submission_filename_csv}' has been created.")
print(f"It contains predictions for {len(submission_df)} farmers.")
print("==================================================")

print("\nPreview of the submission file:")
print(submission_df.head())
